import json
import logging
import time
import requests
from requests.auth import HTTPBasicAuth
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from util import Config

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class TestRunner:

    def __init__(self, vsphere_url = Config.get_url(), vsphere_user = "administrator@vsphere.local", vsphere_pass = "solidF!r3"):
        self.url = vsphere_url
        self.auth = HTTPBasicAuth(vsphere_user, vsphere_pass)
        self.request_headers = {'Content-type': 'application/json'}
        self.logger = logging.getLogger("TestRunner")


    def run_workflow(self, name, params):
        id = self.get_workflow_id(name)

        parameters = {"parameters": []}
        for p in params:
            parameters["parameters"].append(p.as_dict())
        result = requests.post(self.url + "workflows/" + id + "/executions/", json=parameters, auth=self.auth, verify=False, headers=self.request_headers)
        self.logger.info(result.status_code)
        self.logger.info(result.text)

        location = str(result.headers["location"])
        execution_result = self.get_execution(location)

        while execution_result["state"] == "running":
            time.sleep(2)
            execution_result = self.get_execution(location)

        if execution_result["state"] == "completed":
            return self.get_catalog(execution_result["output-parameters"][0]["value"]["sdk-object"]["href"])
        elif execution_result["state"] == "failed":
            raise Exception(execution_result["content-exception"])


    def get_execution(self, href):
        result = requests.get(href + "?showDetails=true", auth=self.auth, verify=False, headers=self.request_headers)
        self.logger.info(result.status_code)
        self.logger.info(result.text)
        return result.json()

    def get_catalog(self, href):
        result = requests.get(href, auth=self.auth, verify=False, headers=self.request_headers)
        self.logger.info(result.status_code)
        self.logger.info(result.text)
        return result.json()

    def get_workflow_id(self, name):
        result = requests.get(self.url + "workflows?maxResult=100&startIndex=0&queryCount=false&conditions=name~" + name, auth=self.auth, verify=False, headers=self.request_headers)
        self.logger.info(result.status_code)
        self.logger.info(result.text)
        if result.status_code != 200:
            raise Exception("Unable to find workflow: " + name)
        workflow = json.loads(str(result.text))
        found = False
        workflow_id = 0
        for wf in workflow["link"]:
            for attr in wf["attributes"]:
                if attr is not None:
                    if attr["name"] == "name" and attr["value"] == name:
                        found = True
                    if attr["name"] == "id":
                        workflow_id = attr["value"]
            if found:
                return workflow_id
            else:
                found = False


    def get_plugin_version(self):
        result = requests.get( self.url + "plugins", auth=self.auth, verify=False, headers=self.request_headers)
        self.logger.info(result.status_code)
        self.logger.info(result.text)
        if result.status_code != 200:
            raise Exception("Unable to get version info ")

        plugins = json.loads(str(result.text))

        for plugin in plugins["plugin"]:
            if plugin["moduleName"] == "SolidFire":
                return plugin["version"]