import json
import unittest

from util import *
from util.Connect import Connect

from util.Parameter import *
from util.TestRunner import TestRunner


class Account(unittest.TestCase):
    tr = TestRunner()
    connection_id = None
    param_conn = None

    def setUp(self):
        self.connection_id = get_attributes_value(Connect().connect(), "id")
        self.param_conn = ConnectionParameter(self.connection_id)
        return

    def test_getAccountById(self):
        # workflow name for this test
        workflow = "GetAccountByID"

        # create parameters
        param_account = StandardParameter("accountID", 35, "number")
        params = [self.param_conn, param_account]

        # run workflow
        result = self.tr.run_workflow(workflow, params)

        # assign test variables
        account = json.loads(get_attributes_value(result, "account"))

        # assertions
        assert account["accountID"] == 125

    def test_deleteInitiators(self):
        # workflow name for this test
        workflow = "DeleteInitiators"

        # create parameters
        param_account = StandardParameter("initiators", [], "Array/number")
        params = [self.param_conn, param_account]

        # run workflow
        result = self.tr.run_workflow(workflow, params)
        v = self.tr.get_plugin_version()
        print(v)

    def test_listAccounts(self):
        # workflow name for this test
        workflow = "ListAccounts"
        params = [self.param_conn]
        # run workflow
        result = self.tr.run_workflow(workflow, params)

        # assign test variables
        account = json.loads(get_attributes_value(result, "account"))

        # assertions
        assert account["accountID"] == 125


    def tearDown(self):
        return

if __name__ == '__main__':
    unittest.main()
