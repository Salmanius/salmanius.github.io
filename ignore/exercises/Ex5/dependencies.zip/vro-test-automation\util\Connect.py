from util.Config import *
from util.Parameter import *
from util.TestRunner import TestRunner


class Connect:

    def connect(self, target = cluster_target, username = cluster_username, password = cluster_password, port = cluster_port, version = None, timeoutMSecs = 30000, vro_url = Config.get_url()):
        workflow = "CreateConnection"
        params = [
            StandardParameter("target", target, "string"),
            StandardParameter("username", username, "string"),
            StandardParameter("password", password, "SecureString"),
            StandardParameter("port", port, "number"),
            StandardParameter("version", version, "string"),
            StandardParameter("timeoutMSecs", timeoutMSecs, "number")
            ]

        tr = TestRunner(vro_url)

        return tr.run_workflow(workflow, params)
