

## How to run tests

To run all tests:

    python -m unittest discover 
    
To run all smoke tests:

    python -m unittest discover -t . smoke/ 

To run one test:

    python test_sandbox.py
