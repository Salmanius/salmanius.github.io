
def get_attributes_value(result, key):
    value = [attr for attr in result["attributes"] if attr["name"] == key]
    if len(value) == 1:
        return value[0]["value"]
    else:
        raise Exception("Unable to find value for key: " + key)
