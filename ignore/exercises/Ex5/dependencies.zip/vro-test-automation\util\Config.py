vro_env = "dev"

dev_url = "https://10.117.61.134:8281/vco/api/"
test_url = "https://10.117.61.62:8281/vco/api/"
test_cluster_url = "https://10.117.61.239:8281/vco/api/"

cluster_target = "10.117.61.60"
cluster_username = "admin"
cluster_password = "admin"
cluster_port = 443
cluster_verify_ssl = False


def get_url():
    if vro_env == "dev":
        return dev_url
    elif vro_env == "test":
        return test_url
    elif vro_env == "test_cluster":
        return test_cluster_url
