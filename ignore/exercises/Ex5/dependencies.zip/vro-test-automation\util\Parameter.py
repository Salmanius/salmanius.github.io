from abc import abstractmethod

from util import Config


class Parameter:
    @abstractmethod
    def as_dict(self):
        return


class StandardParameter(Parameter):
    name = ""
    type_of = ""
    actual_type = ""
    value = None

    def as_dict(self):

        if self.actual_type == "array":
            val_dict = {self.actual_type:
                         {
                             "elements": []
                         }
                     }

            type = self.type_of[self.type_of.index("/")+1:]
            for val in self.value:
                val_dict.get(self.actual_type).get("elements").append({type:{"value":val}})

        else:
            val_dict = {self.actual_type:
                         {"value": self.value}
                     }

        return {"value": val_dict,
                "type": self.type_of,
                "name": self.name,
                "scope": "local"}

    def __init__(self, name, value, type_of):
        self.name = name
        self.value = value
        self.type_of = type_of
        if type_of == "SecureString":
            self.actual_type = "string"
        elif "Array" in type_of:
            self.actual_type = "array"
        else:
            self.actual_type = type_of


class ConnectionParameter(Parameter):
    id = ""

    def as_dict(self):
        return {"value": {"sdk-object":
                              {
                                  "type": "SolidFire:SolidFireConnection",
                                  "href": self.url + "catalog/SolidFire/SolidFireConnection/" + self.id + "/",
                                  "id": self.id,
                               }
                          },
                "type": "SolidFire:SolidFireConnection",
                "name": "connection",
                "scope": "local"}

    def __init__(self, connection_id, vsphere_url = Config.get_url()):
        self.id = connection_id
        self.url = vsphere_url

class LoggingServerArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(host:string,port:number):LoggingServer",
                    "property": [
                        {
                            "id": "host",
                            "value": {
                                "string": {
                                    "value": value["host"]
                                }
                            }
                        },
                        {
                            "id": "port",
                            "value": {
                                "number": {
                                    "value": value["port"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(host:string,port:number):LoggingServer",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements


class CreateInitiatorArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(name:string,alias:string,volumeAccessGroupID:number):CreateInitiator",
                    "property": [
                        {
                            "id": "name",
                            "value": {
                                "string": {
                                    "value": value["name"]
                                }
                            }
                        },
                        {
                            "id": "alias",
                            "value": {
                                "string": {
                                    "value": value["alias"]
                                }
                            }
                        }
                        ,
                        {
                            "id": "volumeAccessGroupID",
                            "value": {
                                "number": {
                                    "value": value["volumeAccessGroupID"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(name:string,alias:string,volumeAccessGroupID:number):CreateInitiator",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements

class ModifyInitiatorArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(initiatorID:number,alias:String,volumeAccessGroupID:number):modifyInitiators",
                    "property": [
                        {
                            "id": "initiatorID",
                            "value": {
                                "number": {
                                    "value": value["initiatorID"]
                                }
                            }
                        },
                        {
                            "id": "alias",
                            "value": {
                                "string": {
                                    "value": value["alias"]
                                }
                            }
                        }
                        ,
                        {
                            "id": "volumeAccessGroupID",
                            "value": {
                                "number": {
                                    "value": value["volumeAccessGroupID"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(initiatorID:number,alias:String,volumeAccessGroupID:number):modifyInitiators",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements


class AddressBlockParamsArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(start:string,size:number,available:string):addressBlockParams",
                    "property": [
                        {
                            "id": "start",
                            "value": {
                                "string": {
                                    "value": value["start"]
                                }
                            }
                        },
                        {
                            "id": "size",
                            "value": {
                                "number": {
                                    "value": value["size"]
                                }
                            }
                        }
                        ,
                        {
                            "id": "available",
                            "value": {
                                "string": {
                                    "value": value["available"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(start:string,size:number,available:string):addressBlockParams",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements


class LunAssignmentArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(volumeID:number,lun:number):LunAssignment",
                    "property": [
                        {
                            "id": "volumeID",
                            "value": {
                                "number": {
                                    "value": value["volumeID"]
                                }
                            }
                        },
                        {
                            "id": "lun",
                            "value": {
                                "number": {
                                    "value": value["lun"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(volumeID:number,lun:number):LunAssignment",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements

class CloneMultipleVolumeParamsArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(volumeID:number,access:string,name:string,newAccountID:number,newSize:number):cloneMultipleVolumeParams",
                    "property": [
                        {
                            "id": "volumeID",
                            "value": {
                                "number": {
                                    "value": value["volumeID"]
                                }
                            }
                        },
                        {
                            "id": "access",
                            "value": {
                                "string": {
                                    "value": value["access"]
                                }
                            }
                        },
                        {
                            "id": "name",
                            "value": {
                                "string": {
                                    "value": value["name"]
                                }
                            }
                        },
                        {
                            "id": "newAccountID",
                            "value": {
                                "number": {
                                    "value": value["newAccountID"]
                                }
                            }
                        },
                        {
                            "id": "newSize",
                            "value": {
                                "number": {
                                    "value": value["newSize"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(volumeID:number,access:string,name:string,newAccountID:number,newSize:number):cloneMultipleVolumeParams",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements

class TrapRecipientArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(host:string,community:string,port:number):TrapRecipients",
                    "property": [
                        {
                            "id": "host",
                            "value": {
                                "string": {
                                    "value": value["host"]
                                }
                            }
                        },
                        {
                            "id": "community",
                            "value": {
                                "string": {
                                    "value": value["community"]
                                }
                            }
                        },
                        {
                            "id": "port",
                            "value": {
                                "number": {
                                    "value": value["port"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(host:string,community:string,port:number):TrapRecipients",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements

class NewDriveArrayCompositeType(Parameter):
    name = ""
    array = []

    def fill_elements(self, elements):
        for value in self.array:
            elements.append({
                "composite": {
                    "type": "CompositeType(driveID:number,block_or_slice:string):driveToAdd",
                    "property": [
                        {
                            "id": "driveID",
                            "value": {
                                "number": {
                                    "value": value["driveID"]
                                }
                            }
                        },
                        {
                            "id": "block_or_slice",
                            "value": {
                                "string": {
                                    "value": value["block_or_slice"]
                                }
                            }
                        }
                    ]
                }
            })
        return elements

    def as_dict(self):
        elements = []
        return {
            "value": {
                "array": {
                    "elements": self.fill_elements(elements)
                }
            },
            "type": "Array/CompositeType(driveID:number,block_or_slice:string):driveToAdd",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, elements):
        self.name = name
        self.array = elements



class QOSCompositeType(Parameter):
    name = ""
    minIOPs = None
    maxIOPs = None
    burstIOPs = None

    def as_dict(self):
        return {
            "value": {
                "composite": {
                    "type": "CompositeType(minIOPs:number,maxIOPs:number,burstIOPs:number):QoS",
                    "property": [
                        {
                            "id": "minIOPs",
                            "value": {
                                "number": {
                                    "value": self.minIOPs
                                }
                            }
                        },
                        {
                            "id": "maxIOPs",
                            "value": {
                                "number": {
                                    "value": self.maxIOPs
                                }
                            }
                        },
                        {
                            "id": "burstIOPs",
                            "value": {
                                "number": {
                                    "value": self.burstIOPs
                                }
                            }
                        }
                    ]
                }
            },
            "type": "CompositeType(minIOPs:number,maxIOPs:number,burstIOPs:number):QoS",
            "name": self.name,
            "scope": "local"
        }

    def __init__(self, name, minIOPs, maxIOPs, burstIOPs):
        self.name = name
        self.minIOPs = minIOPs
        self.maxIOPs = maxIOPs
        self.burstIOPs = burstIOPs

