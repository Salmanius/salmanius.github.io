from solidfire.factory import ElementFactory
import random
import sys
import logging

log = logging.getLogger("solidfire.Element")
log.handlers = []

sfe = ElementFactory.create(sys.argv[1], "admin", "admin")
nodes = list(map((lambda x: x.cip),sfe.list_all_nodes().nodes))
print(random.choice(nodes))