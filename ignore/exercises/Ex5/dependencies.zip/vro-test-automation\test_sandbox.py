import json
import unittest

from util import *
from util.Connect import Connect

from util.Parameter import *
from util.TestRunner import TestRunner


class Sandbox(unittest.TestCase):

    def setUp(self):
        return

    def test_yes(self):
        assert "yes" == "yes"
        return

    def test_notTwo(self):
        assert 2 == 2
        return

    def test_lun_obj(self):
        qos = QOSCompositeType("qos",10,10,10,10)
        print(qos.as_dict())
        return

    def tearDown(self):
        return

if __name__ == '__main__':
    unittest.main()
